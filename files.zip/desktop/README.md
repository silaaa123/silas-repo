# Desktop (Python/Pygame)

Run locally:

1. Create a virtual environment (recommended)
2. pip install -r requirements.txt
3. python main.py

This folder contains the Pygame implementation with the requested win/lose visuals (pink Pac‑Man and confetti on win; bouncing/falling sad emoji on loss).