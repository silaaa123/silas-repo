"""sila's pacpac world - desktop (Pygame)

A compact but playable Pac‑Man style implementation with:
- tile-based maze
- pellets and power pellets
- ghosts with simple AI
- HUD, score, lives
- win: pink Pac‑Man + confetti burst + falling confetti
- lose: sad emoji bouncing/falling

Run: python main.py
"""

import pygame
import sys
import random
import math

# Config
TILE = 24
FPS = 8
WIDTH_TILES = 19
HEIGHT_TILES = 21
SCREEN_W = WIDTH_TILES * TILE
SCREEN_H = HEIGHT_TILES * TILE + 48

# Colors
BLACK = (0, 0, 0)
NAVY = (10, 10, 80)
YELLOW = (255, 220, 40)
PINK = (255, 102, 204)
WHITE = (255, 255, 255)
WALL_COLOR = (33, 33, 255)
PELLET_COLOR = (200, 200, 200)
POWER_COLOR = (255, 160, 120)
GHOST_COLORS = [(255, 0, 0), (255, 128, 0), (0, 255, 255), (255, 128, 255)]

# Simple ASCII maze (source map)
MAZE = [
"###################",
"#........#........#",
"#.###.###.#.###.###",
"#o###.###.#.###.###",
"#.###.###.#.###.###",
"#.................#",
"#.###.#.#####.#.###",
"#.....#...#...#....#",
"#####.### # ###.####",
"    #.#       #.#   ",
"#####.# ##### #.####",
"#........#........#",
"#.###.###.#.###.###",
"#o..#.....P.....#o#",
"###.#.#.#####.#.#.##",
"#.....#...#...#....#",
"#.########.#.######",
"#.................#",
"###################",
]

# Normalize maze size
maze = []
for row in MAZE:
    if len(row) < WIDTH_TILES:
        row = row.ljust(WIDTH_TILES)
    maze.append(row[:WIDTH_TILES])
while len(maze) < HEIGHT_TILES:
    maze.append(' ' * WIDTH_TILES)
maze = maze[:HEIGHT_TILES]

# Helper functions

def grid_to_pixel(pos):
    x, y = pos
    return x * TILE + TILE // 2, y * TILE + TILE // 2

def is_wall(pos):
    x, y = pos
    if x < 0 or x >= WIDTH_TILES or y < 0 or y >= HEIGHT_TILES:
        return True
    return maze[y][x] == '#'

def find_positions(ch):
    res = []
    for y, row in enumerate(maze):
        for x, c in enumerate(row):
            if c == ch:
                res.append((x, y))
    return res

def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

class Player:
    def __init__(self, start):
        self.start = start
        self.pos = start
        self.dir = (0, 0)
        self.next_dir = (0, 0)
        self.score = 0
        self.lives = 3
        self.power_timer = 0
        self.color = YELLOW

    def update(self):
        if self.next_dir != self.dir:
            nx = (self.pos[0] + self.next_dir[0], self.pos[1] + self.next_dir[1])
            if not is_wall(nx):
                self.dir = self.next_dir
        target = (self.pos[0] + self.dir[0], self.pos[1] + self.dir[1])
        if not is_wall(target):
            self.pos = target

    def draw(self, surf):
        px, py = grid_to_pixel(self.pos)
        pygame.draw.circle(surf, self.color, (px, py), TILE // 2 - 2)

class Ghost:
    def __init__(self, start, color):
        self.start = start
        self.pos = start
        self.dir = (0, 0)
        self.color = color
        self.vulnerable = False
        self.vul_timer = 0

    def reset(self):
        self.pos = self.start
        self.dir = (0, 0)
        self.vulnerable = False
        self.vul_timer = 0

    def choose_direction(self, player_pos):
        options = []
        for d in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nxt = (self.pos[0] + d[0], self.pos[1] + d[1])
            if not is_wall(nxt) and (d[0] * -1, d[1] * -1) != self.dir:
                options.append(d)
        if not options:
            options = [(-self.dir[0], -self.dir[1])] if self.dir != (0, 0) else [(1, 0)]
        if random.random() < 0.35:
            best = min(options, key=lambda d: manhattan((self.pos[0] + d[0], self.pos[1] + d[1]), player_pos))
            return best
        return random.choice(options)

    def update(self, player_pos):
        if self.vulnerable:
            self.vul_timer -= 1
            if self.vul_timer <= 0:
                self.vulnerable = False
        self.dir = self.choose_direction(player_pos)
        self.pos = (self.pos[0] + self.dir[0], self.pos[1] + self.dir[1])

    def draw(self, surf):
        px, py = grid_to_pixel(self.pos)
        color = (100, 100, 255) if self.vulnerable else self.color
        pygame.draw.circle(surf, color, (px, py), TILE // 2 - 3)
        eye_color = WHITE if not self.vulnerable else NAVY
        eye_offset = 6
        pygame.draw.circle(surf, eye_color, (px - eye_offset, py - 4), 3)
        pygame.draw.circle(surf, eye_color, (px + eye_offset, py - 4), 3)

class ConfettiParticle:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.vx = random.uniform(-2, 2)
        self.vy = random.uniform(-5, -1)
        self.color = random.choice([(255, 102, 102), (102, 255, 178), (102, 178, 255), (255, 255, 102)])
        self.size = random.randint(2, 5)

    def update(self):
        self.vy += 0.15
        self.x += self.vx
        self.y += self.vy

    def draw(self, surf):
        pygame.draw.rect(surf, self.color, (int(self.x), int(self.y), self.size, self.size))

class EmojiParticle:
    def __init__(self, x, y, char='😢'):
        self.x = x
        self.y = y
        self.vx = random.uniform(-2, 2)
        self.vy = random.uniform(-6, -2)
        self.char = char
        self.angle = random.uniform(-0.2, 0.2)

    def update(self):
        self.vy += 0.25
        self.x += self.vx
        self.y += self.vy
        self.vx *= 0.99

    def draw(self, surf, font):
        txt = font.render(self.char, True, WHITE)
        surf.blit(txt, (int(self.x), int(self.y)))

def init_pellets():
    pellets = set()
    powers = set()
    for y, row in enumerate(maze):
        for x, c in enumerate(row):
            if c == '.':
                pellets.add((x, y))
            elif c == 'o':
                powers.add((x, y))
            elif c == ' ':
                pellets.add((x, y))
    return pellets, powers

def draw_maze(surf):
    for y, row in enumerate(maze):
        for x, c in enumerate(row):
            rect = pygame.Rect(x * TILE, y * TILE, TILE, TILE)
            if c == '#':
                pygame.draw.rect(surf, WALL_COLOR, rect)
            else:
                pygame.draw.rect(surf, NAVY, rect)

def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
    pygame.display.set_caption("sila's pacpac world")
    clock = pygame.time.Clock()

    p_pos = find_positions('P')
    if not p_pos:
        p_pos = [(9, 14)]
    g_pos = find_positions('G')
    if not g_pos:
        g_pos = [(9, 9), (8, 9), (10, 9), (9, 8)]

    player = Player(p_pos[0])
    ghosts = [Ghost(g_pos[i % len(g_pos)], GHOST_COLORS[i % len(GHOST_COLORS)]) for i in range(4)]

    pellets, powers = init_pellets()
    pellets.discard(player.pos)
    for g in ghosts:
        pellets.discard(g.pos)
        powers.discard(g.pos)

    font = pygame.font.SysFont(None, 24)
    bigfont = pygame.font.SysFont(None, 48)
    emoji_font = pygame.font.SysFont(None, 48)

    confetti = []
    emojis = []

    game_over = False
    win = False

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and not game_over:
                if event.key == pygame.K_LEFT:
                    player.next_dir = (-1, 0)
                elif event.key == pygame.K_RIGHT:
                    player.next_dir = (1, 0)
                elif event.key == pygame.K_UP:
                    player.next_dir = (0, -1)
                elif event.key == pygame.K_DOWN:
                    player.next_dir = (0, 1)
                elif event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            elif event.type == pygame.KEYDOWN and game_over:
                # restart
                player = Player(p_pos[0])
                ghosts = [Ghost(g_pos[i % len(g_pos)], GHOST_COLORS[i % len(GHOST_COLORS)]) for i in range(4)]
                pellets, powers = init_pellets()
                pellets.discard(player.pos)
                for g in ghosts:
                    pellets.discard(g.pos)
                    powers.discard(g.pos)
                confetti.clear()
                emojis.clear()
                game_over = False
                win = False

        if not game_over:
            player.update()
            for g in ghosts:
                g.update(player.pos)

            if player.pos in pellets:
                pellets.remove(player.pos)
                player.score += 10
            if player.pos in powers:
                powers.remove(player.pos)
                player.score += 50
                player.power_timer = FPS * 10
                for g in ghosts:
                    g.vulnerable = True
                    g.vul_timer = FPS * 10

            for g in ghosts:
                if g.pos == player.pos:
                    if g.vulnerable:
                        player.score += 200
                        g.reset()
                    else:
                        player.lives -= 1
                        player.pos = player.start
                        player.dir = (0, 0)
                        player.next_dir = (0, 0)
                        for gg in ghosts:
                            gg.reset()
                        if player.lives <= 0:
                            game_over = True
                            win = False
                            # spawn sad emojis
                            for i in range(20):
                                emojis.append(EmojiParticle(random.uniform(50, SCREEN_W-50), random.uniform(20, SCREEN_H/2), '😢'))

            if not pellets and not powers:
                win = True
                game_over = True
                # change pacman color to pink and spawn confetti
                player.color = PINK
                cx = SCREEN_W // 2
                cy = SCREEN_H // 2
                for i in range(120):
                    confetti.append(ConfettiParticle(cx, cy))

        # update particles
        for p in confetti:
            p.update()
        confetti = [c for c in confetti if c.y < SCREEN_H + 50]
        for e in emojis:
            e.update()
        emojis = [e for e in emojis if e.y < SCREEN_H + 100]

        # draw
        screen.fill(BLACK)
        play_surf = pygame.Surface((SCREEN_W, SCREEN_H - 48))
        play_surf.fill(NAVY)
        draw_maze(play_surf)

        for p in pellets:
            px, py = grid_to_pixel(p)
            pygame.draw.circle(play_surf, PELLET_COLOR, (px, py), 3)
        for p in powers:
            px, py = grid_to_pixel(p)
            pygame.draw.circle(play_surf, POWER_COLOR, (px, py), 6)

        for g in ghosts:
            g.draw(play_surf)
        player.draw(play_surf)

        screen.blit(play_surf, (0, 0))

        # HUD
        hud_rect = pygame.Rect(0, SCREEN_H - 48, SCREEN_W, 48)
        pygame.draw.rect(screen, BLACK, hud_rect)
        score_s = font.render(f"Score: {player.score}", True, WHITE)
        lives_s = font.render("Lives: " + "♥" * player.lives, True, WHITE)
        screen.blit(score_s, (8, SCREEN_H - 40))
        screen.blit(lives_s, (220, SCREEN_H - 40))

        if player.power_timer > 0:
            player.power_timer -= 1
            pt = player.power_timer // FPS
            power_s = font.render(f"Power: {pt}s", True, POWER_COLOR)
            screen.blit(power_s, (420, SCREEN_H - 40))

        # draw confetti & emojis
        for c in confetti:
            c.draw(screen)
        for e in emojis:
            e.draw(screen, emoji_font)

        if game_over:
            if win:
                msg = "YOU WIN! Press any key to restart"
            else:
                msg = "GAME OVER! Press any key to restart"
            msg_s = bigfont.render(msg, True, WHITE)
            screen.blit(msg_s, (SCREEN_W // 2 - msg_s.get_width() // 2, SCREEN_H // 2 - msg_s.get_height() // 2))

        pygame.display.flip()
        clock.tick(FPS)


if __name__ == '__main__':
    main()