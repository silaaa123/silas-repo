/* Minimal HTML5/Canvas Pac-Man-like demo
   Simplified gameplay adapted from the desktop version
*/

const TILE = 24;
const WIDTH_TILES = 19;
const HEIGHT_TILES = 21;
const CANVAS_W = TILE*WIDTH_TILES;
const CANVAS_H = TILE*HEIGHT_TILES;

const mazeRows = [
"###################",
"#........#........#",
"#.###.###.#.###.###",
"#o###.###.#.###.###",
"#.###.###.#.###.###",
"#.................#",
"#.###.#.#####.#.###",
"#.....#...#...#....#",
"#####.### # ###.####",
"    #.#       #.#   ",
"#####.# ##### #.####",
"#........#........#",
"#.###.###.#.###.###",
"#o..#.....P.....#o#",
"###.#.#.#####.#.#.##",
"#.....#...#...#....#",
"#.########.#.######",
"#.................#",
"###################",
];

let canvas=document.getElementById('game');
let ctx=canvas.getContext('2d');
canvas.width=CANVAS_W;
canvas.height=CANVAS_H;

function gridToPixel(pos){return [pos[0]*TILE+TILE/2,pos[1]*TILE+TILE/2]}
function isWall(x,y){
  if(x<0||x>=WIDTH_TILES||y<0||y>=HEIGHT_TILES) return true;
  return maze[y][x]==='#';
}

let maze = [];
for(let r of mazeRows){
  maze.push(r.padEnd(WIDTH_TILES,' '));
}

function find(ch){let res=[];for(let y=0;y<maze.length;y++){for(let x=0;x<maze[y].length;x++){if(maze[y][x]===ch)res.push([x,y])}}return res}

let playerPos=find('P')[0]||[9,14];
let ghosts=find('G');
if(ghosts.length===0) ghosts=[[9,9],[8,9],[10,9],[9,8]];

let pellets=new Set();
let powers=new Set();
for(let y=0;y<maze.length;y++)for(let x=0;x<maze[y].length;x++){let c=maze[y][x];if(c==='.'||c===' ') pellets.add(x+','+y); if(c==='o') powers.add(x+','+y)}
pellets.delete(playerPos[0]+','+playerPos[1]);

let dir=[0,0];
let nextDir=[0,0];
let score=0;let lives=3;let powerTimer=0;
let confetti=[];let emojis=[];let gameOver=false;let win=false;

window.addEventListener('keydown',e=>{
  if(!gameOver){
    if(e.key==='ArrowLeft') nextDir=[-1,0];
    if(e.key==='ArrowRight') nextDir=[1,0];
    if(e.key==='ArrowUp') nextDir=[0,-1];
    if(e.key==='ArrowDown') nextDir=[0,1];
  } else { // restart
    playerPos=[9,14]; dir=[0,0]; nextDir=[0,0]; score=0; lives=3; powerTimer=0; pellets.clear(); powers.clear();
    for(let y=0;y<maze.length;y++)for(let x=0;x<maze[y].length;x++){let c=maze[y][x];if(c==='.'||c===' ') pellets.add(x+','+y); if(c==='o') powers.add(x+','+y)}
    pellets.delete(playerPos[0]+','+playerPos[1]); confetti=[]; emojis=[]; gameOver=false; win=false;
  }
});

function update(){
  if(nextDir[0]!==dir[0] || nextDir[1]!==dir[1]){
    let nx=playerPos[0]+nextDir[0], ny=playerPos[1]+nextDir[1];
    if(!isWall(nx,ny)) dir=nextDir.slice();
  }
  let tx=playerPos[0]+dir[0], ty=playerPos[1]+dir[1];
  if(!isWall(tx,ty)) playerPos=[tx,ty];

  let key=playerPos[0]+','+playerPos[1];
  if(pellets.has(key)){pellets.delete(key); score+=10}
  if(powers.has(key){powers.delete(key); score+=50; powerTimer=120}

  if(pellets.size===0 && powers.size===0){ win=true; gameOver=true; for(let i=0;i<120;i++){confetti.push({x:CANVAS_W/2,y:CANVAS_H/2,vx:(Math.random()-0.5)*6,vy:(Math.random()*-4-1),col:['#ff6666','#66ffb2','#66b2ff','#ffff66'][Math.floor(Math.random()*4)],size:2+Math.floor(Math.random()*4)})}}

  confetti.forEach(c=>{c.vy+=0.15;c.x+=c.vx;c.y+=c.vy}); confetti=confetti.filter(c=>c.y<CANVAS_H+50);
  emojis.forEach(e=>{e.vy+=0.25;e.x+=e.vx;e.y+=e.vy}); emojis=emojis.filter(e=>e.y<CANVAS_H+100);
}

function draw(){
  ctx.fillStyle='#000'; ctx.fillRect(0,0,CANVAS_W,CANVAS_H);
  for(let y=0;y<maze.length;y++){
    for(let x=0;x<maze[y].length;x++){
      if(maze[y][x]==='#'){ctx.fillStyle='#2121ff'; ctx.fillRect(x*TILE,y*TILE,TILE,TILE)} else {ctx.fillStyle='#051028'; ctx.fillRect(x*TILE,y*TILE,TILE,TILE)}
    }
  }
  pellets.forEach(k=>{let [x,y]=k.split(',').map(Number); ctx.fillStyle='#c8c8c8'; ctx.beginPath(); ctx.arc(x*TILE+TILE/2,y*TILE+TILE/2,3,0,Math.PI*2); ctx.fill()});
  powers.forEach(k=>{let [x,y]=k.split(',').map(Number); ctx.fillStyle='#ff9f80'; ctx.beginPath(); ctx.arc(x*TILE+TILE/2,y*TILE+TILE/2,6,0,Math.PI*2); ctx.fill()});

  ctx.fillStyle='#ff0000'; ctx.beginPath(); ctx.arc(9*TILE+TILE/2,9*TILE+TILE/2,10,0,Math.PI*2); ctx.fill();

  ctx.fillStyle = (win? '#ff66cc' : '#ffd82a'); ctx.beginPath(); ctx.arc(playerPos[0]*TILE+TILE/2, playerPos[1]*TILE+TILE/2, TILE/2-2, 0, Math.PI*2); ctx.fill();

  confetti.forEach(c=>{ctx.fillStyle=c.col; ctx.fillRect(c.x,c.y,c.size,c.size)});
  ctx.fillStyle='#fff'; ctx.font='32px sans-serif'; emojis.forEach(e=>{ctx.fillText('😢', e.x, e.y)});

  ctx.fillStyle='#000'; ctx.fillRect(0,CANVAS_H-40,CANVAS_W,40); ctx.fillStyle='#fff'; ctx.font='16px sans-serif'; ctx.fillText('Score: '+score,8,CANVAS_H-18); ctx.fillText('Lives: '+String.fromCharCode(9829).repeat(lives),220,CANVAS_H-18);

  if(gameOver){ ctx.fillStyle='#fff'; ctx.font='22px sans-serif'; ctx.textAlign='center'; ctx.fillText(win? 'YOU WIN! Press any key to restart' : 'GAME OVER! Press any key to restart', CANVAS_W/2, CANVAS_H/2); }
}

function loop(){ update(); draw(); requestAnimationFrame(loop); }
loop();