# notes

This repository contains two implementations of "sila's pacpac world":

1. desktop/ — Python/Pygame version. Run locally with Python 3.8+.
2. web/ — HTML5 Canvas version playable in Chrome/ChromeOS.

CI (GitHub Actions)

- On push to main or pacpac-scaffold the workflow attempts to build a Linux desktop binary and deploy the web folder to GitHub Pages.

Notes

- Desktop PyInstaller builds on GitHub Actions may require additional packaging tweaks for a fully working binary; the workflow provides a starting point.