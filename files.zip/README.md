# sila's pacpac world

This repository contains the full source for "sila's pacpac world" — a polished Pac‑Man style game with both a native Python/Pygame desktop build and a web (HTML5) build playable in Chrome/ChromeOS.

What you'll find in this branch (pacpac-scaffold)

- `desktop/` — Python/Pygame implementation (playable locally)
- `web/` — HTML5 (Canvas) implementation playable in Chrome/ChromeOS and other browsers
- `.github/workflows/ci-build.yml` — CI that builds the desktop Linux artifact and deploys the web build to GitHub Pages
- `LICENSE` — MIT

Quick start (desktop):

1. Install Python 3.8+ and pip
2. Install dependencies: cd desktop && pip install -r requirements.txt
3. Run: python main.py

Quick start (web):

1. Serve `web/` from a static server (or enable GitHub Pages in the repository settings to publish `/web`)
2. Open `web/index.html` in Chrome/ChromeOS

Packaging and CI

- The GitHub Actions workflow will build a Linux executable with PyInstaller and publish the `web/` folder to GitHub Pages.